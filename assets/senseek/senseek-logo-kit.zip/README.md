# Senseek Logo

**Senseek**  
Semantic Page Search  
Find what you mean.

## 设计

本版从应用的实际操作出发：**在当前网页里，用意思找内容，再把相关句子高亮在原文中。**

- 页面轮廓与正文行：正在阅读的网页内容。
- 正文中的高亮带：命中的原文句子，与应用内的高亮颜色一致。
- 右下角放大镜：在当前内容中查找、定位；镜片保持留白，避免画成「缩小」符号。

图形直接表达「页面内查找并高亮」。字标保留全小写 `senseek`，颜色延续界面的深绿、浅绿高亮和纸白色。

## 使用文件

| 文件 | 用途 |
| --- | --- |
| `senseek-logo.svg` | 标志与字标组合，透明底，适合浅色界面 |
| `senseek-logo-inverse.svg` | 深色界面的反白字标组合 |
| `senseek-lockup.svg` | 包含 Semantic Page Search 与 Find what you mean. 的完整组合 |
| `senseek-wordmark.svg` | 独立字标 |
| `senseek-mark.svg` / `senseek-mark-inverse.svg` | 独立页面搜索标志，透明底 |
| `senseek-icon.svg` / `senseek-icon-light.svg` | 圆角方形应用图标，深浅两版 |
| `senseek-logo-mono.svg` | 黑色单色标志，适合单色印刷 |
| `exports/*.png` | 对应的透明 PNG，宽度 1024 或 2400 像素 |
| `exports/icon-16.png` 等 | 浏览器工具栏及扩展图标：16、32、48、128、256、512 px |
| `previews/senseek-preview.png` | 主视觉预览 |
| `previews/senseek-brand-sheet.png` | 浅色、深色及小尺寸应用预览 |
| `senseek-logo-kit.zip` | 可交付的完整资源包 |

修订版本：`senseek-logo-kit-v2.zip`；带 `-v2` 后缀的 PNG 预览为本次页面搜索图形重设计。

Logo 与字标 SVG 均无需外部字体或网络资源。文字已转为轮廓，可在浏览器、Figma、Illustrator、Inkscape 等工具中使用。

这是新增的 Senseek 品牌资源包。应用原有图标和 JEV Find 名称未在本次设计中覆盖。

## 色彩

- Forest：`#23483B`
- Highlight：`#D6EDAC`
- Paper：`#F6F7F1`

独立图形保留至少四分之一图形宽度的留白；文字组合建议至少 160 px 宽。16–48 px 的工具栏使用独立应用图标，不缩小完整字标。16 px 版本加粗页面与镜片轮廓，并去除高亮带内的微小细节。

## 字体与生成

字标基于 Manrope 700，以轻微负字距作调整。Manrope 使用 SIL Open Font License，许可文本见 `source/OFL.txt`，源文件来自 Google Fonts：
https://github.com/google/fonts/tree/main/ofl/manrope

制作方式：原生 SVG 几何路径 + 字体转轮廓，通过本地 Chromium 导出透明 PNG。未调用图片生成 API。

设计说明：为浏览器语义搜索工具 Senseek 制作与实际用途一致的标志，组合网页正文、命中的高亮句子与搜索放大镜。使用深绿、浅绿高亮与纸白色，文字为 Semantic Page Search / Find what you mean.。优先让使用者看出页面内查找与原文定位，保持浏览器工具栏小尺寸可读。

在仓库根目录可重新生成（需要 Python 的 fontTools，以及项目已有的 Playwright）：

```sh
python scripts/design-senseek.py
node scripts/render-senseek.mjs
```
